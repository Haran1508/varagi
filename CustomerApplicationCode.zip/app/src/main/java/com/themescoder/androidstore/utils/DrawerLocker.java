package com.themescoder.androidstore.utils;

public interface DrawerLocker {
    void setDrawerEnabled(boolean enabled);
}
